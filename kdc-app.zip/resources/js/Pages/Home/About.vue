<template>
    <section
        id="about"
        class="dark:bg-gray-800 dark:text-gray-100 bg-white pb-8"
    >
        <div class="container flex flex-col justify-center p-4 mx-auto md:p-8">
            <div class="flex items-center justify-center gap-2">
                <hr
                    class="w-20 mb-10 border-2 border-gray-700 rounded-xl dark:border-gray-500"
                />
                <h2
                    class="mb-12 text-4xl font-bold leading-none text-center sm:text-5xl"
                >
                    About us
                </h2>
                <hr
                    class="w-20 mb-10 border-2 border-gray-700 rounded-xl dark:border-gray-500"
                />
            </div>

            <div class="text-center space-y-4">
                <div class="mt-8">
                    <h3 class="font-bold text-2xl">Our Mission</h3>
                    <p class="mt-1 dark:text-gray-400 text-justify">
                        Kasilag-Zaide Dental Clinic is dedicated to running the
                        best network of dental offices that offers our clients
                        the highest caliber dental care at the most reasonable
                        price. We work hard to provide our clients with
                        top-notch dental care that enhances their health,
                        wellbeing, and quality of life.
                    </p>
                </div>
                <div class="pt-8">
                    <h3 class="font-bold text-2xl">Our Goal</h3>
                    <p class="mt-1 dark:text-gray-400 text-justify">
                        We care about your general health as well as your dental
                        visit experience in addition to your teeth. Going to the
                        dentist is something that many people fear. Most likely
                        as a result of a painful event from the past or simple
                        apprehension about the unknown. We therefore make an
                        extra effort to put patients at ease during dental
                        visits by compassionately listening to their needs and
                        concerns. Additionally, each process will be fully
                        explained, and any questions they may have will be
                        answered. We evaluate your present oral health
                        conditions at your initial appointment with us. Your
                        dentist will next go over the choices available to you
                        for improving your situation and averting any potential
                        future dental health issues while preparing a treatment
                        plan. Our goal is to alter your perception of dentistry
                        and to enhance your dental health, which promotes
                        improved general health.
                    </p>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
