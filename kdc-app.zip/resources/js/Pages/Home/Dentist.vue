<template>
    <section class="py-6">
        <div
            class="container flex flex-col items-center justify-center p-4 mx-auto space-y-8 sm:p-10"
        >
            <h1
                class="text-4xl text-gray-100 font-bold leading-none text-center sm:text-5xl"
            >
                Our Dentist
            </h1>
            <p class="max-w-2xl text-center dark:text-gray-400 text-gray-200">
                We have the best dentist in the country, they are all
                professionals and they are all well trained.
            </p>
            <div
                class="flex flex-row flex-wrap-reverse justify-center text-white"
            >
                <div class="flex flex-col justify-center m-8 text-center">
                    <img
                        alt=""
                        class="self-center bg-white flex-shrink-0 w-24 h-24 mb-4 bg-center bg-cover rounded-full dark:bg-gray-500"
                        src="resources/dentist-boy.png"
                    />
                    <p class="text-xl font-semibold leading-tight">
                        Dr. Raymond S. Kasilag
                    </p>
                    <p class="dark:text-gray-400 text-gray-300">Dentist</p>
                </div>
                <div class="flex flex-col justify-center m-8 text-center">
                    <img
                        alt=""
                        class="self-center bg-white flex-shrink-0 w-24 h-24 mb-4 bg-center bg-cover rounded-full dark:bg-gray-500"
                        src="resources/dentist-girl.png"
                    />
                    <p class="text-xl font-semibold leading-tight">
                        Dr. Desiree Z. Kasilag
                    </p>
                    <p class="dark:text-gray-400 text-gray-300">Dentist</p>
                </div>
                <div class="flex flex-col justify-center m-8 text-center">
                    <img
                        alt=""
                        class="self-center bg-white flex-shrink-0 w-24 h-24 mb-4 bg-center bg-cover rounded-full dark:bg-gray-500"
                        src="resources/dentist-boy.png"
                    />
                    <p class="text-xl font-semibold leading-tight">
                        Dr. Mark S. Kasilag
                    </p>
                    <p class="dark:text-gray-400 text-gray-300">Dentist</p>
                </div>
            </div>
        </div>
    </section>
</template>
