<template>
    <section
        id="service"
        class="py-6 dark:bg-gray-800 bg-white dark:text-gray-100"
    >
        <div class="container p-4 mx-auto space-y-16 sm:p-10">
            <div class="space-y-4">
                <h3 class="text-2xl font-bold leading-none sm:text-5xl">
                    Our Services
                </h3>
                <p class="max-w-2xl dark:text-gray-400">
                    We offer the best services in the country, we have the best
                    dentist and the best equipments.
                </p>
            </div>
            <div class="grid w-full grid-cols-1 gap-6 lg:grid-cols-2">
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-01.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">Teeth Whitening</h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            Stained teeth? Not to worry for our Dentists’ Teeth
                            Whitening service or some might call tooth
                            bleaching, uses hydrogen peroxide or Carbamide
                            peroxide-based bleaching solutions that can break
                            down those nasty stains to smaller pieces making the
                            stain colors less concentrated which makes your
                            stained teeth whiter and your smile brighter.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-02.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">Teeth Cleaning</h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            Teeth cleaning is a process which not only removes
                            stains, but the prophylaxis cleaning procedure which
                            can clean the teeth more thoroughly this procedure
                            can also stop the teeth from developing diseases
                            like periodontal and gingivitis.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-03.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">
                            Orthodontic Treatment
                        </h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            Orthodontists do teeth straightening, installation
                            and fitting of braces, retainers, and bands. We also
                            do treatment on dental abnormalities like unaligned
                            teeth and bite problems.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-04.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">
                            Modern Dentistry Services
                        </h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            Modern dentistry services uses advanced equipment
                            such as X-rays, Intraoral scanners, and AI-guided
                            surgeries to make the procedure and result more
                            precise. but of course, the procedure will be done
                            by our trained experts so you can rest easy.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-05.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">
                            Teeth/Dental Bonding
                        </h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            A Cosmetic Dentistry treatment where the dentist
                            applies resin to the affected or cracked areas of
                            the teeth that is the same color of the teeth,
                            shaping and changing their color to what the patient
                            desires. These kinds of treatment are to make
                            improvements to your teeth with the application of
                            cosmetics.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-06.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">Cosmetic Fillings</h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            A dental procedure that is mainly focused on
                            improving appearance of the teeth. These procedures
                            include fillings and implants. Improving the overall
                            look of the teeth and smile
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-07.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">Dentures</h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            Removable implants for covering up lost teeth,
                            whether it be partial or a complete fitting of
                            Dentures our experts will make sure that you can
                            smile with any worries. These procedures can take a
                            few weeks and several appointments to check the
                            condition of the implants.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-08.jpg"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">
                            Root Canal Therapy
                        </h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            This procedure removes the pulp and nerve in the
                            roots of the teeth which can help clean and shape
                            the inside of the root canal then, seals the space
                            made for the procedure.
                        </p>
                    </div>
                </div>
                <div
                    class="flex space-x-6 hover:bg-gray-100 dark:hover:bg-gray-700 hover:-translate-y-4 transition-all duration-150 p-4 rounded-lg"
                >
                    <img
                        alt=""
                        class="flex flex-shrink-0 object-cover h-56 w-56 mb-4 bg-center rounded-sm dark:bg-gray-500"
                        src="resources/service-09.png"
                    />
                    <div class="flex flex-col">
                        <h4 class="text-xl font-semibold">Tooth Extractions</h4>
                        <p class="text-sm dark:text-gray-400 text-justify mt-6">
                            Tooth extraction can be more of an operation rather
                            than a treatment. These procedures are necessary
                            only if a patient has severe damages in the teeth,
                            which can decay overtime. This procedure is to
                            eliminate bacteria from the decay and improve the
                            development of the teeth.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
